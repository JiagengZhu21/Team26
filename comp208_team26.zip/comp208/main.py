from Dashboard import canvasI

canvasI.window()